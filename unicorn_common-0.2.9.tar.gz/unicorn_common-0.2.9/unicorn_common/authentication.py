from django.apps import apps
from django.conf import settings
from django.contrib.auth.models import User
from rest_framework_simplejwt.authentication import JWTAuthentication, JWTTokenUserAuthentication
from rest_framework_simplejwt.settings import api_settings


class UnicornAuthentication(JWTTokenUserAuthentication):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def get_user(self, validated_token):
        """
        Attempts to find and return a user using the given validated token.
        """

        user = None
        # get Redis by token
        # try:
        #     user_id = validated_token[api_settings.USER_ID_CLAIM]
        # except KeyError:
        #     raise InvalidToken(
        #         _('Token contained no recognizable user identification'))

        # try:
        #     user = self.user_model.objects.get(
        #         **{api_settings.USER_ID_FIELD: user_id})
        # except self.user_model.DoesNotExist:
        #     raise AuthenticationFailed(
        #         _('User not found'), code='user_not_found')

        # if not user.is_active:
        #     raise AuthenticationFailed(
        #         _('User is inactive'), code='user_inactive')
        # print("get super validated_token ", validated_token[api_settings.USER_ID_CLAIM])
        _id = validated_token[api_settings.USER_ID_CLAIM]
        auth_model = apps.get_model(
            app_label=settings.TOKEN_AUTH_APP, model_name="Player")
        player = auth_model.objects.get(pk=_id)
        user = super().get_user(validated_token)

        # print("ok. the user", user)
        return user
