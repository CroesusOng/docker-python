
import logging

from decouple import config
from django.core.cache import CacheHandler, cache

logger = logging.getLogger('django')


class ClientInfo:

    @staticmethod
    def onConnect(channel_name, token):
        res = cache.get(token)

        broadcast = config(
            'BROADCAST_TOKEN', default="7774bc7945ee5b916ab059f224f9bc8722ba628e843ba20ba09b2ce3f98218f1")
        if res:
            key = "ct_{}".format(channel_name)
            cache.set(key, token)
            info = cache.get(token)
            if info:
                info['channel'] = channel_name
                print("update the channel ", info)
                cache.set(token, info)
            return True
        elif broadcast == token:
            return True

        logger.warning("sorry I, don't know you.")
        return False

    @staticmethod
    def onDisconnect(channel_name):
        key = "ct_{}".format(channel_name)
        token = cache.get(key)
        if token:
            p_id = ClientInfo.getPlayerID(token)
            players_info = cache.get("players_info")

            if p_id in players_info:
                logger.info("remove {}".format(players_info[p_id]))
                del players_info[p_id]

            cache.set("players_info", players_info)

            cache.delete(token)
        cache.delete(key)

    @staticmethod
    def getPlayerID(token):
        p_id = None
        info = cache.get(token)
        if info:
            logger.info("delete the info {}".format(info))
            players_info = cache.get("players_info")
            if players_info:
                p_id = info['p_id']
        return p_id

    @staticmethod
    def setPlayerInfo(p_id, token):
        players_info = cache.get("players_info")
        if players_info is None:
            players_info = {}
        players_info[p_id] = token
        cache.set("players_info", players_info)

    @staticmethod
    def getPlayerChannel(p_id):
        p_id = int(p_id)
        players_info = cache.get("players_info")
        if players_info:
            if p_id in players_info:
                token = players_info[p_id]
                info = cache.get(token)
                if info:
                    channel = info['channel']
                    return channel
            else:
                logger.info("player id not found {}".format(p_id))
        else:
            logger.error("no players info ")
        return None

    @staticmethod
    def getOnlinePlayerIds():
        return list(cache.get("players_info").keys())
