from enum import Enum, IntEnum


class EnumBase(Enum):

    @classmethod
    def nameList(cls):
        return list(map(lambda x: x.name, cls))

    @classmethod
    def valueList(cls):
        return list(map(lambda x: x.value, cls))

    @classmethod
    def choices(cls):
        return tuple([(tag.value, tag.name) for tag in cls])

    @classmethod
    def dictionary(cls):
        return dict(map(lambda x: x, cls.choices()))

    @classmethod
    def name_dictionary(cls):
        choices = tuple([(tag.name, tag.value) for tag in cls])
        return dict(map(lambda x: x, choices))


class Role(int, EnumBase):
    Admin = 1
    Operator = 2
    CustomerService = 3
    Merchant = 10
    Agent = 20

    @classmethod
    def isStaff(cls, role):
        if role in cls.Staffs():
            return True
        return False

    @classmethod
    def isAgent(cls, role):
        if role == cls.Agent:
            return True
        return False

    @classmethod
    def Staffs(cls):
        return [cls.Admin, cls.Operator, cls.CustomerService]


class WalletType(int, EnumBase):
    Unicorn = 1
    Center = 2


class MerchantStatus(int, EnumBase):
    Trial = 1
    Production = 2


class TransactionType(int, EnumBase):
    Deposit = 1         # 存款      +
    Withdraw = 2        # 提款      -
    Bet = 3             # 投注      -
    Payout = 4          # 派彩      +
    Return = 5          # 回退      +
    Rollback = 6        # 沖正      +
    Repayout = 7        # 重派彩    +
    Jackpot = 8         # 紅利      X
    Void = 9            # 無效      +
    Reward = 10         # 獎金      X
    BackendAdjust = 11  # 後臺調整  +/-


class GameState(int, EnumBase):
    Trial = 1
    Production = 2
    Suspend = 3


class GameCategory(int, EnumBase):
    Lottery = 1
    Chess = 2
    Electric = 3


class IssueStatus(int, EnumBase):
    Init = 1
    Start = 2
    End = 3
    Paying = 4
    Paid = 5
    Repaid = 6
    Void = 7


class ResultSource(int, EnumBase):
    SelfRandom = 1


class OddsType(int, EnumBase):
    Static = 1
    Dynamic = 2


class BetStatus(int, EnumBase):
    Init = 1
    Bet = 2
    Paid = 3
    Void = 4
    Repaid = 5


class EventType(str, EnumBase):
    Init = 'Init'
    Init_CB = 'Init_CB'
    Bet = 'Bet'
    Bet_CB = 'Bet_CB'
    IssueInit = 'IssueInit'
    IssueStart = 'IssueStart'
    IssueLatest_CB = 'IssueLatest_CB'
    Result = 'Result'
    Payout = 'Payout'
    Repayout = 'Repayout'
    CurrentBet = 'CurrentBet'
    CurrentBet_CB = 'CurrentBet_CB'
    CurrentBetSummary = 'CurrentBetSummary'
    BetHistory = 'BetHistory'
    BetHistory_CB = 'BetHistory_CB'
    Cashflow = 'Cashflow'
    Cashflow_CB = 'Cashflow_CB'
    GameResult = 'GameResult'
    GameResult_CB = 'GameResult_CB'
    IssueVoid = 'IssueVoid'
    Loby = 'LobyInfo'
    Room = 'RoomInfo'
    Balance = 'Balance'
    Balance_CB = 'Balance_CB'
    WinLose = 'WinLose'
    HeadCount = 'HeadCount'
    HeadCount_CB = 'HeadCount_CB'
    Kick = 'Kick'
