import logging
import urllib.parse

import requests
from decouple import config
from django.conf import settings

logger = logging.getLogger(__name__)


class CashflowHelper:

    @staticmethod
    def getBalance(player_id, extra=None):
        url = config('PLAYER_URL', default="http://127.0.0.1:8000")
        action = 'backend/players/{}/'.format(player_id)
        headers = {'content-type': 'application/json', }

        if extra and 'authorization' in extra:
            headers['Authorization'] = extra['authorization']
        else:
            logger.info("No auth {}".format(extra))
        url = urllib.parse.urljoin(url, action)
        r = requests.get(url=url, headers=headers)

        if not str(r.status_code).startswith('2') or settings.DEBUG_LEVEL:
            logger.debug("r.text: {}".format(r.text))

        return r.json()['wallet']['amount']

    @staticmethod
    def _post(url, data, extra=None):
        if settings.DEBUG_LEVEL:
            logger.debug("url: {}, data: {}".format(url, data))
        headers = {'content-type': 'application/json', }

        if extra and 'authorization' in extra:
            headers['Authorization'] = extra['authorization']
        else:
            logger.info("No auth {}".format(extra))

        r = requests.post(
            url=url,
            json=data,
            headers=headers
        )

        if not str(r.status_code).startswith('2') or settings.DEBUG_LEVEL:
            logger.debug("r.text: {}".format(r.text))

        return r

    @ staticmethod
    def _request(action_type, data, extra=None):
        url = config('PLAYER_URL', default="http://127.0.0.1:8000")
        action = 'backend/cashflow_requests/{}/'.format(action_type)
        url = urllib.parse.urljoin(url, action)
        r = CashflowHelper._post(url, data, extra)
        success = str(r.status_code).startswith('2')
        return success, r.json()

    @staticmethod
    def depositRequest(deposits, extra=None):
        return CashflowHelper._request('deposit', deposits, extra)

    @staticmethod
    def withdrawRequest(withdraws, extra=None):
        return CashflowHelper._request('withdraw', withdraws, extra)

    @ staticmethod
    def _commit(action_type, data, extra=None):
        url = config('PLAYER_URL', default="http://127.0.0.1:8000")
        action = 'backend/cashflow_commits/{}/'.format(action_type)
        url = urllib.parse.urljoin(url, action)
        r = CashflowHelper._post(url, data, extra)
        success = str(r.status_code).startswith('2')
        return success, r.json()

    @ staticmethod
    def depositCommit(deposits, extra=None):
        return CashflowHelper._commit('deposit', deposits, extra)

    @ staticmethod
    def withdrawCommit(withdraws, extra=None):
        return CashflowHelper._commit('withdraw', withdraws, extra)

    @ staticmethod
    def deposit(requests, extra=None):
        # 1. trigger cashflow request
        requestResult, requestData = CashflowHelper.depositRequest(
            requests, extra)

        if not requestResult:
            logger.error(
                "deposit() deposit request failed: {}".format(
                    requestData))
            return requestResult, requestData

        # 2. pack commits base on request data
        commits = CashflowHelper._packCommits(requestData)

        # 3. trigger cashflow commit
        commitResult, commitData = CashflowHelper.depositCommit(
            commits, extra)

        if not commitResult:
            logger.error(
                "deposit() deposit commit failed: {}".format(
                    commitData))
        return commitResult, commitData

    @ staticmethod
    def withdraw(requests, extra=None):
        # 1. trigger cashflow request
        requestResult, requestData = CashflowHelper.withdrawRequest(
            requests, extra)

        if not requestResult:
            logger.error(
                "withdraw() withdraw request failed: {}".format(
                    requestData))
            return requestResult, requestData

        # 2. pack commits base on request data
        commits = CashflowHelper._packCommits(requestData)

        # 3. trigger cashflow commit
        commitResult, commitData = CashflowHelper.withdrawCommit(
            commits, extra)

        if not commitResult:
            logger.error(
                "withdraw() withdraw commit failed: {}".format(
                    commitData))
        return commitResult, commitData

    @staticmethod
    def _packCommits(requestData):
        commits = []
        for item in requestData:
            commit = {
                'merchant': item['merchant']['id'],
                'player': item['player']['id'],
                'amount': abs(float(item['amount'])),
                'transaction_id': item['transaction_id'],
                'transaction_type': item['transaction_type'],
                'request_id': item['id']
            }
            commits.append(commit)
        return commits
