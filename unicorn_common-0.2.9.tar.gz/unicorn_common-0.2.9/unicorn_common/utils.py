
import hashlib
import math
import random
import string
from datetime import datetime

from django.utils import timezone


def getRandomAlphaNumericString(stringLength=8):
    lettersAndDigits = string.ascii_letters + string.digits
    return ''.join((random.choice(lettersAndDigits) for i in range(stringLength)))


def getRandomNumericString(stringLength=4):
    return ''.join((random.choice(string.digits) for i in range(stringLength)))


def getSha256ByTime(time=None):
    if time is None:
        time = timezone.now()
    return hashlib.sha256(str(time).encode()).hexdigest()


def getTransactionId():
    now = timezone.localtime(timezone.now())
    date_string = datetime.strftime(now, '%Y%m%d')
    base = datetime(now.year, now.month, now.day, 0, 0).timestamp()

    new_id = (now.timestamp()-base)*1000
    new_id = math.floor(new_id)

    transactionID = date_string + str(new_id).zfill(8)
    return transactionID


def timeInRange(start, end, x):
    """Return true if x is in the range [start, end]"""
    if start <= end:
        return start <= x <= end
    else:
        return start <= x or x <= end


def genBallsArray(probs, ball_number=10000):
    # logger.info("genBallsArray() probs: {}".format(len(probs)))
    balls = []
    for key, value in probs.items():
        balls.extend([key]*round(value*ball_number))

    # logger.info(
    #     "genBallsArray() len of balls: {}".format(len(balls)))

    # shuffle array
    random.shuffle(balls)

    # logger.info("genBallsArray() balls shuffled")
    return balls


def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip
