import json
import urllib.parse

from asgiref.sync import async_to_sync
from decouple import Csv, config
# from channels.layers import get_channel_layer
from websocket import create_connection


class WebSocketHelper:

    @staticmethod
    def wsclient(data):
        websocket_url = config('WEBSOCKET_URL', default="ws://127.0.0.1:38000")
        broadcast = config(
            'BROADCAST_TOKEN', default="7774bc7945ee5b916ab059f224f9bc8722ba628e843ba20ba09b2ce3f98218f1")
        api = 'ws/gameslobby/?token={}'.format(broadcast)
        url = urllib.parse.urljoin(websocket_url, api)
        ws = create_connection(url)
        ws.send(json.dumps(data))

        ws.close()

    @staticmethod
    def sendTaskToClient(data):
        print("sendTaskToClient", data)
        async_to_sync(WebSocketHelper.wsclient(data))
        print("done")
