import json
import logging

from .define import EventType

logger = logging.getLogger(__name__)


class Event:
    def __init__(self, data):
        self.data = data
        if 'merchant_id' in data:
            self.merchant_id = data['merchant_id']
        else:
            self.merchant_id = None
        if 'player_id' in data:
            self.player_id = data['player_id']
        else:
            self.player_id = None

    def setMerchantID(self, id):
        self.merchant_id = id

    def getMerchantID(self):
        return self.merchant_id

    def setPlayerID(self, id):
        self.player_id = id

    def getPlayerID(self):
        return self.player_id

    def getEvent(self):
        if self.data and 'event' in self.data:
            return self.data['event']
        return None

    def getGameID(self):
        if self.data and 'game_id' in self.data:
            return int(self.data['game_id'])
        return 0

    def getRegionID(self):
        if self.data and 'region_id' in self.data:
            return int(self.data['region_id'])
        return 0

    def getData(self):
        if self.data and 'data' in self.data:
            return self.data['data']
        return None

    def getDataByKey(self, key):
        if self.data and key in self.data:
            return self.data[key]
        return None

    def getOriginData(self):
        if self.data and 'data' in self.data:
            data = self.data
            if self.merchant_id:
                data['merchant_id'] = self.merchant_id
            if self.player_id:
                data['player_id'] = self.player_id
            return data
        return None

    def getToken(self):
        return self.token

    def getIssueNo(self):
        if self.data and 'issue_no' in self.data:
            return self.data['issue_no']
        return None

    def getStartTime(self):
        if self.data and 'start_time' in self.data:
            return self.data['start_time']
        return None

    def getEndTime(self):
        if self.data and 'end_time' in self.data:
            return self.data['end_time']
        return None

    @staticmethod
    def createEvent(data):
        event = None
        try:
            data = json.loads(data)
            if 'event' in data:
                event = Event(data)
        except Exception as e:
            logger.exception(e)

        return event

    @staticmethod
    def createIssueInitEvent(game_id, region_id, date):
        data = {
            "event": EventType.IssueInit,
            "game_id": game_id,
            "region_id": region_id,
            "date": date
        }
        return Event.createEvent(json.dumps(data))

    @staticmethod
    def createIssueStartEvent(game_id, region_id, issue_no, start_time, end_time):
        data = {
            "event": EventType.IssueStart,
            "game_id": game_id,
            "region_id": region_id,
            "issue_no": issue_no,
            "start_time": start_time,
            "end_time": end_time,
        }
        print("createIssueStartEvent(): ", data)
        return Event.createEvent(json.dumps(data))

    @staticmethod
    def createResultEvent(game_id, region_id, issue_no, extra=None):
        data = {
            "event": EventType.Result.value,
            "game_id": game_id,
            "region_id": region_id,
            "issue_no": issue_no,
        }
        print("createResultEvent(): ", data)
        return Event.createEvent(json.dumps(data))

    @staticmethod
    def createPayoutEvent(game_id, region_id, issue_no, extra=None):
        data = {
            "event": EventType.Payout.value,
            "game_id": game_id,
            "region_id": region_id,
            "issue_no": issue_no,
        }
        print("createPayoutEvent(): ", data)
        return Event.createEvent(json.dumps(data))

    @staticmethod
    def createGetBalanceEvent(merchant_id, player_id):
        data = {
            "event": EventType.Balance.value,
            "merchant_id": merchant_id,
            "player_id": player_id,
        }
        return Event.createEvent(json.dumps(data))

    @staticmethod
    def createHeadCountEvent(game_id, region_id):
        data = {
            "event": EventType.HeadCount.value,
            "game_id": game_id,
            "region_id": region_id,
        }
        return Event.createEvent(json.dumps(data))

    @staticmethod
    def createLatestIssues(issues):
        data = {
            "event": EventType.IssueLatest_CB.value,
            "data": []
        }
        for item in issues:
            issue = {
                'game_id': item['game_id'],
                'region_id': item['region_id'],
                'issue_no': item['issue_no'],
                'start_time': item['start_time'],
                'end_time': item['end_time'],
                'countdown_time': item['countdown_time'],
                "odds_data": item['odds_data']
            }
            data['data'].append(issue)

        return Event.createEvent(json.dumps(data))
